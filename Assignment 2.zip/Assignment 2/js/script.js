function recommendRestaurant() {

    let diet =
        document.getElementById("diet").value;

    let budget =
        document.getElementById("budget").value;

    let purpose =
        document.getElementById("purpose").value;

    let restaurant = "";
    let description = "";

    // Rule-based recommendation logic

    if (diet === "Vegan") {

        restaurant = "Green Bowl";
        description =
        "Green Bowl offers healthy vegan meals and sustainable dining.";

    }

    else if (diet === "Halal") {

        restaurant = "Royal Feast";
        description =
        "Royal Feast provides premium halal cuisine for families and groups.";

    }

    else if (
        budget === "High" &&
        purpose === "Date"
    ) {

        restaurant = "Ocean Pearl";
        description =
        "Ocean Pearl is perfect for romantic seafood dining experiences.";

    }

    else if (
        purpose === "Business"
    ) {

        restaurant = "Tokyo Flame";
        description =
        "Tokyo Flame provides a stylish environment suitable for business meetings.";

    }

    else {

        restaurant = "Bella Italia";
        description =
        "Bella Italia offers comfortable family-friendly Italian dining.";
    }

    // Display Result

    document.getElementById(
        "resultSection"
    ).style.display = "block";

    document.getElementById(
        "recommendResult"
    ).innerHTML =

    "<h3>" + restaurant + "</h3>" +
    "<p>" + description + "</p>";

    // Pass restaurant to reservation page

    let reserveButton =
        document.getElementById("reserveBtn");

    reserveButton.style.display = "inline-block";

    reserveButton.onclick = function () {

        window.location.href =
        "reservation.html?restaurant=" +
        encodeURIComponent(restaurant);
    };
}