function recommendRestaurant() {

    let diet =
        document.getElementById("diet").value;

    let budget =
        document.getElementById("budget").value;

    let purpose =
        document.getElementById("purpose").value;

    let restaurant = "";
    let description = "";

    // Rule-based recommendation logic

    if (diet === "Vegan") {

        restaurant = "Green Bowl";
        description =
        "Green Bowl offers healthy vegan meals and sustainable dining.";

    }

    else if (diet === "Halal") {

        restaurant = "Royal Feast";
        description =
        "Royal Feast provides premium halal cuisine for families and groups.";

    }

    else if (
        budget === "High" &&
        purpose === "Date"
    ) {

        restaurant = "Ocean Pearl";
        description =
        "Ocean Pearl is perfect for romantic seafood dining experiences.";

    }

    else if (
        purpose === "Business"
    ) {

        restaurant = "Tokyo Flame";
        description =
        "Tokyo Flame provides a stylish environment suitable for business meetings.";

    }

    else {

        restaurant = "Bella Italia";
        description =
        "Bella Italia offers comfortable family-friendly Italian dining.";
    }

    // Display Result

    document.getElementById(
        "resultSection"
    ).style.display = "block";

    document.getElementById(
        "recommendResult"
    ).innerHTML =

    "<h3>" + restaurant + "</h3>" +
    "<p>" + description + "</p>";

    // Pass restaurant to reservation page

    let reserveButton =
        document.getElementById("reserveBtn");

    reserveButton.style.display = "inline-block";

    reserveButton.onclick = function () {

        window.location.href =
        "reservation.html?restaurant=" +
        encodeURIComponent(restaurant);
    };
}

function validateRegister() {

    let username =
        document.getElementById(
            "username"
        ).value.trim();

    let email =
        document.getElementById(
            "email"
        ).value.trim();

    let phone =
        document.getElementById(
            "phone"
        ).value.trim();

    let password =
        document.getElementById(
            "password"
        ).value;

    let confirmPassword =
        document.getElementById(
            "confirmPassword"
        ).value;

    let gender =
        document.getElementById(
            "gender"
        ).value;

    let errorMessage = "";

    // Username

    let usernamePattern =
        /^[A-Za-z0-9_]{5,}$/;

    if (!usernamePattern.test(username)) {

        errorMessage +=
        "Username must be at least 5 characters and contain only letters, numbers and underscores.<br>";
    }

    // Email

    let emailPattern =
        /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if (!emailPattern.test(email)) {

        errorMessage +=
        "Enter a valid email address.<br>";
    }

    // Phone

    let phonePattern =
        /^[0-9]{8,15}$/;

    if (!phonePattern.test(phone)) {

        errorMessage +=
        "Phone number must contain 8–15 digits only.<br>";
    }

    // Password

    let passwordPattern =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{10,}$/;

    if (!passwordPattern.test(password)) {

        errorMessage +=
        "Password must contain minimum 10 characters, uppercase, lowercase, number and special character.<br>";
    }

    // Confirm Password

    if (password !== confirmPassword) {

        errorMessage +=
        "Passwords do not match.<br>";
    }

    // Gender

    if (gender === "") {

        errorMessage +=
        "Please select gender.<br>";
    }

    // Display Errors

    document.getElementById(
        "errorMessage"
    ).innerHTML = errorMessage;

    // Stop Submission

    if (errorMessage !== "") {

        return false;
    }

    return true;
}

// Deposit Update

function updateDeposit() {

let restaurant =
document.getElementById(
"restaurant"
).value;

document.getElementById("restaurant")
.addEventListener("change", updateDeposit);

function updateDeposit() {

    let restaurant =
        document.getElementById("restaurant").value;

    let deposit =
        document.getElementById("deposit");

    if (restaurant == "Italian Bistro") {
        deposit.value = "$30";
    }
    else if (restaurant == "Ocean Grill") {
        deposit.value = "$50";
    }
    else if (restaurant == "Spice Garden") {
        deposit.value = "$40";
    }
    else {
        deposit.value = "";
    }
}



document.getElementById(
"deposit"
).value = deposit;
}

// Payment Toggle

function togglePaymentFields() {

let payment =
document.getElementById(
"payment"
).value;

document.getElementById(
"voucherSection"
).style.display =
payment === "Voucher"
? "block"
: "none";

document.getElementById(
"cardSection"
).style.display =
payment === "Online"
? "block"
: "none";
}

// Same Email

function copyEmail() {

if (
document.getElementById(
"sameEmail"
).checked
) {

document.getElementById(
"billingEmail"
).value =

document.getElementById(
"email"
).value;
}
}

// Pre-fill Restaurant

window.onload = function () {

let params =
new URLSearchParams(
window.location.search
);

let restaurant =
params.get("restaurant");

if (restaurant) {

document.getElementById(
"restaurant"
).value =
restaurant;

updateDeposit();
}
};

// Validation

function validateReservation() {

let error = "";

let email =
document.getElementById(
"email"
).value;

let phone =
document.getElementById(
"phone"
).value;

let date =
new Date(
document.getElementById(
"date"
).value
);

let today =
new Date();

let people =
document.getElementById(
"people"
).value;

let payment =
document.getElementById(
"payment"
).value;

let card =
document.getElementById(
"card"
).value;

if (
email === ""
) {

error +=
"Email required<br>";
}

if (
phone.length < 10
) {

error +=
"Phone must have 10 digits<br>";
}

if (
date < today
) {

error +=
"Reservation cannot be in past<br>";
}

if (
people <= 0
) {

error +=
"People must be greater than 0<br>";
}

// Card Validation

if (
payment === "Online"
) {

if (
!(
card.length === 15 ||
card.length === 16
)
) {

error +=
"Card must be 15 or 16 digits<br>";
}
}

document.getElementById(
"reservationError"
).innerHTML =
error;

if (
error !== ""
) {

return false;
}

return true;
}